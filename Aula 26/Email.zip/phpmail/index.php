<?php 
header("Location:http://www.amigainformaticacaxias.com.br/home");
